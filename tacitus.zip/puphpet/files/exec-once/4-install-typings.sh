#!/bin/bash
echo "------------ START NPM PACKAGES   ------------"

sudo npm install -g bower
sudo npm install -g node-sass
sudo npm install -g gulp@3.9.1
sudo npm install -g gulp-bower
sudo npm install -g laravel-elixir@5.0.0

echo "------------ END INSTALL PACKAGES ------------"