.test <- function() BiocGenerics:::testPackage("inSilicoMerging")
