require("inSilicoMerging") || stop("unable to load inSilicoMerging package")
inSilicoMerging:::.test()
