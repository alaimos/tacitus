# apply geneNormESet on list of eSets
#-------------------------------------------------------------------------------
mergeGENENORM = function(esets)
{
  esets = lapply(esets, geneNormESet);
  eset = mergeNONE(esets);  
}

#-------------------------------------------------------------------------------
geneNormESet = function(eset)
{
  tmp  <- exprs(eset)
  tmp1 <- do.call(rbind, lapply(split(tmp, 1:nrow(tmp)), function(x) {
    x <- x - mean(x, na.rm=TRUE)
    x <- x / sd(x, na.rm=TRUE)
    return (x)
  }))
  dimnames(tmp1) <- dimnames(tmp)
  exprs(eset) <- tmp1
  return(eset);
}
