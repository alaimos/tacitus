WEBSERVICE = "https://insilicodb.com/app/interface/"
CACHE_DIR = "cache";


#-------------------------------------------------------------------------------
checkHeader = function(header)
{
	if(is.null(header$value())) { error(ERR_NO_CONNECTION); }
	
	if(header$value()['status']==404) { error(ERR_NO_DATA); }
	
	if(header$value()['status']==500) { error(ERR_INTERNAL); }
	
	if(header$value()['status']!=200) { error(ERR_NO_CONNECTION); }
	
	return(TRUE);
}

#-------------------------------------------------------------------------------
checkBinary = function(data, header)
{
	if(!is.element("binary",header$value()))
	{
		json = fromJSON(rawToChar(data));
		error(json$msg);
	}
	return(TRUE);
}

#-------------------------------------------------------------------------------
getInSilicoJSON = function(action, interested=NULL, lst=NULL)
{  
	address = pp(WEBSERVICE,action);
	header = basicHeaderGatherer();
	curl<- getCurlHandle(cookiefile='.cookie.txt',
			cookiejar='.cookie.txt',
			followlocation=TRUE,
			ssl.verifypeer = FALSE);
	
#   options = curlOptions(followlocation=TRUE) # enables redirects
	
	# check if arguments are named: 'Key=value' instead of 'value'
	
	lst = lapply(lst, as.character);
	debug(pp('Access: ', address, pp(lst, collapse=", ")));
	if((length(lst)!=0) &
			(!all(is.character(names(lst)))))
	{ error("Incorrectly used this function. Please check documentation."); }
	
	#   headerfunction=header$update,
	tryCatch({
				response = suppressWarnings(postForm(address,  curl=curl, .encoding="UTF-8", .params=lst, 
								.opts = list(ssl.verifypeer = FALSE)));
			},
			error=function(x){ error(pp(ERR_NO_CONNECTION,': ',x));}
	);
#   checkHeader(header);
	rm(curl);
	gc();
	
	json = fromJSON(response);
	
# print returned info message(s)
	if(is.element("msg",names(json))){
		if(is.list(json[["msg"]])){
			sapply(json[["msg"]],function(x){ msg(x);});
		}
		else{
			msg(json[["msg"]]);  
		}
	}
	
# if 'success' is not in the json response or it's false, exit
	if(!is.element("success",names(json))){ 
		error("Stopped because of previous errors");
	}
	if(json[["success"]]==FALSE){
		error("Stopped because of previous errors");
	}
	
# if the element that we are interested in is not in the json response, also exit
	if(!is.null(interested)){
		if(is.element(interested, names(json))){
			return(json[[interested]]);
		}
		else{
			error(pp(ERR_NO_KEY, interested));
		}
	}
	return(json);
}

#-------------------------------------------------------------------------------
readInSilicoCache = function(fileName)
{
	if(file.access(CACHE_DIR,mode=7)== -1) { dir.create(CACHE_DIR); }
	file = file.path(CACHE_DIR,fileName);
	if(file.access(file,mode=4)==0)
	{
		msg("Requested dataset found in local file: ",file);
		return(file);
	}
	else { return(NULL); }
}

#-------------------------------------------------------------------------------
writeInSilicoCache = function(data,fileName)
{
	if(file.access(CACHE_DIR,mode=7)== -1) { dir.create(cache); }
	file = file.path(CACHE_DIR,fileName);
	fileCon = file(file,"wb");
	writeBin(data,fileCon);
	close(fileCon);
	msg("Requested dataset stored in local file: ",file);
	return(file);
}

#-------------------------------------------------------------------------------
getInSilicoBinary = function(request, params)
{
	action = pp(WEBSERVICE, request,
			pp(names(params),"=",params,collapse="&"));
#  debug(action);
	
	header=basicHeaderGatherer();
	curl<- getCurlHandle(cookiefile='.cookie.txt',
			cookiejar='.cookie.txt',
			followlocation=TRUE,
			ssl.verifypeer = FALSE);
	
	tryCatch({data = getBinaryURL(action,curl=curl,headerfunction=header$update);},
			error=function(x){ error(pp(ERR_NO_CONNECTION,' ',x));} );
	
	rm(curl);
	gc();  
	checkHeader(header);
	checkBinary(data,header);
	
	return(data);
}

#------------------------------------------------------------------------------
getInSilicoDatasetInfo = function(request, ...) 
{
	dataset = getInSilicoJSON(request, "dataset", ...);
	msg(pp('Dataset ',pp(dataset ,collapse=", ")));
	return(dataset);
}

#-----------------------------------------------------------------------------
getFile = function(info, request) {
	debug(pp('Dataset ',pp(info ,collapse=", ")));
	if((!is.null(info[["path"]]) & 
				(info[["state"]]=="found" | info[["state"]]=="finished") ))
	{
		fileName = info[["path"]];
		file = readInSilicoCache(fileName);
		
		if(is.null(file)) 
		{ 
			data = getInSilicoBinary(request, info);
			file = writeInSilicoCache(data,fileName);
		}
		
		tryCatch({eset = get(load(file))}, 
				error=function(e){error("Corrupted file: ",file);});
		return(eset);
	}
	else
	{
		return(NULL);
	}
}

#------------------------------------------------------------------------------
getInSilicoMeasurement = function(lst)
{
	info = getInSilicoDatasetInfo("getmeasurementinfo", lst);
	getFile(info, "getmeasurement?");
}

#-------------------------------------------------------------------------------
getInSilicoDataset = function(lst)
{
	info = getInSilicoDatasetInfo("getdatasetinfo", lst);
	getFile(info, "getdataset?");
}

#-------------------------------------------------------------------------------
getInSilicoCurationInfo = function(lst)
{
	info = getInSilicoJSON("getcurations", lst=lst);
	
	pref = info[["preferred"]];
	
	printCuration = function(cur)
	{
		prefTxt = "(preferred)";
		if(pref!=cur[["curid"]]) { prefTxt="";}
		
		msg("============================================");
		msg(" curation id: ",format(cur[["curid"]],width=8),prefTxt);
		msg("============================================");
		msg(" curator:   ",cur[["curator"]]);
		msg(" date:      ",substr(cur[["date"]], 1, 10));
		msg(" keywords:  ",cur[["keywords"]]);
		msg("");
	}
	
	msg("");
	tmp = lapply(info$curations, printCuration);
}

#-------------------------------------------------------------------------------
getInSilicoDatasets = function(lst)
{
	platforms = getPlatforms(lst[["dataset"]]);
	l = lapply(platforms, function(x){
				tryCatch({
							lst = append(lst, list(platform = x));
							getInSilicoDataset(lst);
						}, error = function(e){
							message(e);
						});
			});
	names(l) = platforms;
	return(l);
}

#-------------------------------------------------------------------------------
getInSilicoAnnotations = function(lst)
{
	annot = getInSilicoJSON("getannotations", "annotations", lst);
	return(createPhenoFrame(annot));
} 

#-------------------------------------------------------------------------------
createPhenoFrame = function(annot)
{
	#if no annotations, return empty pData
	if(length(annot)==0) { return(new("AnnotatedDataFrame")); }
	
	keywords = names(annot[[1]]);
	samples = names(annot);
	
	## Warning: all measurements must contain the same annotation terms.
	M = matrix(NA,nrow=length(samples),
			ncol=length(keywords),
			dimnames=list(samples, keywords));
	
	for(i in samples) 
	{
		M[i,keywords] <- unlist(annot[[i]])[keywords];
	}
	
	myPhenoFrame = new("AnnotatedDataFrame",
			data = as.data.frame(M),
			dimLabels=c("Measurements","Keywords"));
	return(myPhenoFrame);
}
