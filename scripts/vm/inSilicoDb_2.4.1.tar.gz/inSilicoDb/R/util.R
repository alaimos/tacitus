#DEBUG = TRUE;
DEBUG = FALSE;

pp    = function(...) { paste(...,sep=""); }
catn  = function(...) { message(...,sep="","\n"); }
error = function(...) { stop(...,call.=FALSE); }

msg   = function(...) { message("  INSILICODB: ",...); }
debug = function(...) { if(DEBUG) { msg("(DEBUG)  ",...); } }

ERR_NO_CONNECTION = "Webservice not accessible. Please check your internet connection.";
ERR_INTERNAL = "Internal Server Error. Please contact admin.";
ERR_NO_DATA = "Retrieving dataset failed. Please contact admin.";
ERR_NO_ANNOT = "Requested file has no annotation. Please contact admin.";
ERR_NO_KEY = "Response from webservice does not contain ";
