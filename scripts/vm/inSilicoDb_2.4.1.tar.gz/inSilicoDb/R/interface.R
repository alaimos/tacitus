#-------------------------------------------------------------------------------
getPlatforms = function(dataset)
{
  lst = list("dataset" = dataset);
  return(getInSilicoJSON("getplatforms", 'platforms', lst));
}

#-------------------------------------------------------------------------------
getDefaultCuration = function(dataset)
{
  lst = list("dataset" = dataset);
  return(getInSilicoJSON("getdefaultcuration",'curation', lst));
}

#-------------------------------------------------------------------------------
getCurationInfo = function(dataset)
{
  lst = list("dataset" = dataset);
  getInSilicoCurationInfo(lst);
}
#-------------------------------------------------------------------------------
getDataset = function(dataset, platform, ...)
{
  lst = list("dataset" = dataset, "platform" = platform, ...);
  return(getInSilicoDataset(lst));
}

#-------------------------------------------------------------------------------
getDatasets = function(dataset, ...)
{
  lst = list("dataset" = dataset, ...);
  return(getInSilicoDatasets(lst));
}

#-------------------------------------------------------------------------------
getAnnotations = function(dataset, ...)
{
  lst = list("dataset" = dataset, ...);
  return(getInSilicoAnnotations(lst));
}

#-------------------------------------------------------------------------------
getDatasetList = function(...)
{
  lst = list(...);
  return(getInSilicoJSON("getdatasetlist","datasets", lst));
}


#-------------------------------------------------------------------------------
getDatasetPlatformList = function(...)
{
  lst = list(...);
  return(getInSilicoJSON("getdatasetplatformlist","datasets", lst));
}

#-------------------------------------------------------------------------------
InSilicoLogin = function(login, password)
{
  lst = list("login" = login, "password" = password);  
  return(getInSilicoJSON("login","id", lst));
}

#-------------------------------------------------------------------------------
InSilicoLogout = function()
{
  getInSilicoJSON("logout");
}

#-------------------------------------------------------------------------------
getInSilicoUserDetails = function()
{
  return(getInSilicoJSON("user", "user"));
}

#------------------------------------------------------------------------------
getDatasetInfo = function(dataset, platform, ...)
{
  lst = list("dataset" = dataset, "platform" = platform, ...);
  return(getInSilicoDatasetInfo("getdatasetinfo", lst)); 
}

#-------------------------------------------------------------------------------
getPlatformList = function(...) 
{
	lst = list(...);
	return(getInSilicoJSON("getplatformlist", "platform", lst));
}
