#!/bin/bash
echo "------------ START INSTALL TYPINGS ------------"

### install typings

# sudo npm install -g typings

echo "------------ END INSTALL TYPINGS ------------"